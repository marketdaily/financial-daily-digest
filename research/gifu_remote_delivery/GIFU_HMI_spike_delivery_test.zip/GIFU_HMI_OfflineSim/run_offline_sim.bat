@echo off
set EB=C:\EBpro
if not exist "%EB%\cMTViewer.exe" (
  echo EasyBuilder Pro not found in %EB%.
  echo Please install EasyBuilder Pro (free^) from https://www.weintek.com/ and run again,
  echo or edit the EB= line above to your install folder.
  pause
  exit /b 1
)
cd /d "%EB%"
start "" cMTViewer.exe -fs "%~dp0project\project" -allinone
